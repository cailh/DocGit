p1 vim
run p2 vim
sleep 2
vim.exe
